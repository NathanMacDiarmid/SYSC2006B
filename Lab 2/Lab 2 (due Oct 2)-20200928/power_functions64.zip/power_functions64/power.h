/* SYSC 2006 Lab 2, Part 1.
 *
 * DO NOT MODIFY THIS FILE! 
 */
 
int power1(int, int);
int power2(int, int);
int power3(int, int);
int power4(int, int);
